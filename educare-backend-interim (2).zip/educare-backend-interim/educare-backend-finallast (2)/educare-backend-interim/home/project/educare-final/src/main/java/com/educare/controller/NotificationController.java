package com.educare.controller;

import com.educare.dto.request.NotificationRequest;
import com.educare.dto.response.NotificationResponse;
import com.educare.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize; // <-- import
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    // ============================================
    // SEND NOTIFICATION (ADMIN ONLY)
    // ============================================
    @PostMapping("/send")
    @PreAuthorize("hasRole('ADMIN')") // <-- only admin can call
    public ResponseEntity<String> sendNotification(@RequestBody NotificationRequest request) {

        if ((request.getRoles() == null || request.getRoles().isEmpty()) &&
            (request.getUserIds() == null || request.getUserIds().isEmpty()) &&
            !Boolean.TRUE.equals(request.getSendToAll())) {
            return ResponseEntity.badRequest().body("No target users provided");
        }

        notificationService.sendNotification(request);
        return ResponseEntity.ok("Notification sent successfully!");
    }

    // ============================================
    // GET USER NOTIFICATIONS
    // ============================================
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<NotificationResponse>> getUserNotifications(@PathVariable Long userId) {
        List<NotificationResponse> notifications = notificationService.getUserNotifications(userId)
                .stream()
                .map(NotificationResponse::from)
                .toList();
        return ResponseEntity.ok(notifications);
    }
}
package com.educare.service;

import com.educare.dto.request.StudentRequest;
import com.educare.dto.response.StudentResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Student;
import com.educare.model.User;
import com.educare.repository.StudentRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;

    public List<StudentResponse> getAllStudents() {
        return studentRepository.findAll().stream().map(StudentResponse::from).toList();
    }

    public StudentResponse getStudentById(Long id) {
        return StudentResponse.from(findById(id));
    }

    public StudentResponse createStudent(StudentRequest request) {
        Student.StudentBuilder builder = Student.builder()
            .name(request.getName())
            .dob(request.getDob())
            .gender(request.getGender())
            .contactInfo(request.getContactInfo())
            .program(request.getProgram())
            .parentEmail(request.getParentEmail())
            .parentName(request.getParentName())
            .status(request.getStatus() != null ? request.getStatus() : Student.StudentStatus.ACTIVE);

        // Link parent user if provided
        if (request.getParentUserId() != null) {
            User parentUser = userRepository.findById(request.getParentUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getParentUserId()));
            builder.parentUser(parentUser);
        }

        // Link student user account if provided
        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
            builder.user(user);
        }

        return StudentResponse.from(studentRepository.save(builder.build()));
    }

    public StudentResponse updateStudent(Long id, StudentRequest request) {
        Student student = findById(id);
        if (request.getName() != null) student.setName(request.getName());
        if (request.getDob() != null) student.setDob(request.getDob());
        if (request.getGender() != null) student.setGender(request.getGender());
        if (request.getContactInfo() != null) student.setContactInfo(request.getContactInfo());
        if (request.getProgram() != null) student.setProgram(request.getProgram());
        if (request.getParentEmail() != null) student.setParentEmail(request.getParentEmail());
        if (request.getParentName() != null) student.setParentName(request.getParentName());
        if (request.getStatus() != null) student.setStatus(request.getStatus());

        if (request.getParentUserId() != null) {
            User parentUser = userRepository.findById(request.getParentUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getParentUserId()));
            student.setParentUser(parentUser);
        }

        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
            student.setUser(user);
        }

        return StudentResponse.from(studentRepository.save(student));
    }

    public void deleteStudent(Long id) {
        Student student = findById(id);
        student.setStatus(Student.StudentStatus.INACTIVE);
        studentRepository.save(student);
    }

    public List<StudentResponse> searchStudents(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name)
            .stream().map(StudentResponse::from).toList();
    }

    public Student findById(Long id) {
        return studentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Student", id));
    }
}

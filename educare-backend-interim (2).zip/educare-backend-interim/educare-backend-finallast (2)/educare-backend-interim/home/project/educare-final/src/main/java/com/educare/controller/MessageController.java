package com.educare.controller;

import com.educare.dto.request.MessageRequest;
import com.educare.dto.response.ApiResponse;
import com.educare.dto.response.MessageResponse;
import com.educare.model.User;
import com.educare.service.MessageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
@RequiredArgsConstructor
@Tag(name = "Messages", description = "Teacher sends messages to parents — via in-app and/or email")
public class MessageController {

    private final MessageService messageService;

    @GetMapping("/inbox")
    @PreAuthorize("hasAnyRole('ADMIN','PARENT','TEACHER')")
    @Operation(summary = "Get all messages for current user")
    public ResponseEntity<ApiResponse<List<MessageResponse>>> getInbox(
            @AuthenticationPrincipal User currentUser) {
        return ResponseEntity.ok(ApiResponse.success(
            messageService.getInbox(currentUser.getUserId())));
    }

    @PostMapping("/send")
    @PreAuthorize("hasRole('TEACHER')")
    @Operation(
        summary = "Teacher sends message to parent — TEACHER ONLY",
        description = """
            Only teachers can send messages to parents.
            
            Required fields:
            - toUserId: Parent's user ID
            - content: Message content
            
            Optional fields:
            - subject: Message subject/title
            - studentId: Which student this message is about
            - sendEmail: true/false — whether to also send via email (default: false)
            
            When sendEmail=true, the parent will receive both an in-app notification
            AND an email to their registered email address.
            """
    )
    public ResponseEntity<ApiResponse<MessageResponse>> sendToParent(
            @Valid @RequestBody MessageRequest request,
            @AuthenticationPrincipal User teacherUser) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success("Message sent",
                messageService.sendTeacherMessageToParent(request, teacherUser)));
    }

    @PutMapping("/{id}/read")
    @PreAuthorize("hasAnyRole('TEACHER','PARENT','ADMIN')")
    @Operation(summary = "Mark a message as read")
    public ResponseEntity<ApiResponse<MessageResponse>> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success("Message marked as read",
            messageService.markAsRead(id)));
    }

    // @DeleteMapping("/{id}")
    // @Operation(summary = "Delete a message")
    // public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
    //     messageService.deleteMessage(id);
    //     return ResponseEntity.ok(ApiResponse.success("Message deleted", null));
    // }
}

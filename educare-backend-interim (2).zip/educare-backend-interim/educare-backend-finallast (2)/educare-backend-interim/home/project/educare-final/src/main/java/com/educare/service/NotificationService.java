package com.educare.service;

import com.educare.dto.request.NotificationRequest;
import com.educare.model.Notification;
import com.educare.model.User;
import com.educare.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserService userService;
    private final EmailService emailService;

    // ============================================
    // SEND NOTIFICATION
    // ============================================
    public void sendNotification(NotificationRequest request) {

        Set<User> usersToNotify = new HashSet<>(); // Avoid duplicates

        // Case 1: All users
        if (Boolean.TRUE.equals(request.getSendToAll())) {
            usersToNotify.addAll(userService.getAllUsersEntity());
        }

        // Case 2: Specific users
        if (request.getUserIds() != null && !request.getUserIds().isEmpty()) {
            for (Long userId : request.getUserIds()) {
                User user = userService.getUserEntityById(userId);
                if (user != null) usersToNotify.add(user);
            }
        }

        // Case 3: Multiple roles
        if (request.getRoles() != null && !request.getRoles().isEmpty()) {
            for (String roleStr : request.getRoles()) {
                try {
                    User.Role role = User.Role.valueOf(roleStr.toUpperCase());
                    List<User> usersByRole = userService.getUsersEntityByRole(role);
                    usersToNotify.addAll(usersByRole);
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid role: " + roleStr);
                }
            }
        }

        // Throw error if no target users
        if (usersToNotify.isEmpty()) {
            throw new RuntimeException("No target users provided");
        }

        // Process notifications
        for (User user : usersToNotify) {
            processNotification(user, request);
        }
    }

    // ============================================
    // CORE LOGIC
    // ============================================
    private void processNotification(User user, NotificationRequest request) {
        if (user == null) return;

        String title = request.getTitle() != null ? request.getTitle() : "No Title";
        String message = request.getMessage() != null ? request.getMessage() : "No Message";

        boolean emailSent = false;

        // Send Email if requested
        if (request.isSendEmail() && user.getEmail() != null && !user.getEmail().isEmpty()) {
            try {
                emailService.sendNotificationEmail(
                        user.getEmail(),
                        user.getName() != null ? user.getName() : "User",
                        title,
                        message
                );
                emailSent = true;
            } catch (Exception e) {
                System.err.println("Failed to send email to userId: " + user.getUserId());
                e.printStackTrace();
            }
        }

        // Save to DB
        try {
            Notification notification = Notification.builder()
                    .title(title)
                    .message(message)
                    .userId(user.getUserId() != null ? user.getUserId() : 0L)
                    .userName(user.getName() != null ? user.getName() : "Unknown")
                    .userEmail(user.getEmail() != null ? user.getEmail() : "unknown@example.com")
                    .role(user.getRole() != null ? user.getRole().name() : "UNKNOWN")
                    .emailSent(emailSent)
                    .createdAt(LocalDateTime.now())
                    .build();

            notificationRepository.save(notification);
        } catch (Exception e) {
            System.err.println("Failed to save notification for userId: " + user.getUserId());
            e.printStackTrace();
        }
    }

    // ============================================
    // GET NOTIFICATIONS FOR A USER
    // ============================================
    public List<Notification> getUserNotifications(Long userId) {
        return notificationRepository.findByUserId(userId);
    }
}
package com.educare.service;

import com.educare.dto.response.ReportResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Report;
import com.educare.model.User;
import com.educare.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final ReportRepository reportRepository;

    public List<ReportResponse> getAllReports() {
        return reportRepository.findAll().stream().map(ReportResponse::from).toList();
    }

    public List<ReportResponse> getReportsByScope(Report.ReportScope scope) {
        return reportRepository.findByScope(scope).stream().map(ReportResponse::from).toList();
    }

    public ReportResponse getReportById(Long id) {
        return ReportResponse.from(reportRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Report", id)));
    }

    public ReportResponse generateReport(Report.ReportScope scope, String parametersJson, User generatedBy) {
        Report report = Report.builder()
            .scope(scope)
            .parametersJson(parametersJson)
            .metricsJson("{\"generated\": true}")
            .generatedBy(generatedBy)
            .build();
        return ReportResponse.from(reportRepository.save(report));
    }
}

package com.educare.dto.response;

import com.educare.model.Student;
import lombok.*;
import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StudentResponse {
    private Long studentId;
    private String name;
    private LocalDate dob;
    private Student.Gender gender;
    private String contactInfo;
    private String program;
    private String parentEmail;
    private String parentName;
    private Long parentUserId;
    private Long userId;
    private Student.StudentStatus status;

    public static StudentResponse from(Student s) {
        return StudentResponse.builder()
            .studentId(s.getStudentId())
            .name(s.getName())
            .dob(s.getDob())
            .gender(s.getGender())
            .contactInfo(s.getContactInfo())
            .program(s.getProgram())
            .parentEmail(s.getParentEmail())
            .parentName(s.getParentName())
            .parentUserId(s.getParentUser() != null ? s.getParentUser().getUserId() : null)
            .userId(s.getUser() != null ? s.getUser().getUserId() : null)
            .status(s.getStatus())
            .build();
    }
}

package com.educare.service;

import com.educare.dto.response.KPIResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.KPI;
import com.educare.repository.KPIRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class KPIService {

    private final KPIRepository kpiRepository;

    public List<KPIResponse> getAllKPIs() {
        return kpiRepository.findAll().stream().map(KPIResponse::from).toList();
    }

    public KPIResponse getKPIById(Long id) {
        return KPIResponse.from(kpiRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("KPI", id)));
    }

    public KPIResponse createKPI(String name, String definition,
                                  BigDecimal target, String reportingPeriod) {
        KPI kpi = KPI.builder()
            .name(name)
            .definition(definition)
            .target(target)
            .currentValue(BigDecimal.ZERO)
            .reportingPeriod(reportingPeriod)
            .build();
        return KPIResponse.from(kpiRepository.save(kpi));
    }

    public KPIResponse updateCurrentValue(Long id, BigDecimal currentValue) {
        KPI kpi = kpiRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("KPI", id));
        kpi.setCurrentValue(currentValue);
        return KPIResponse.from(kpiRepository.save(kpi));
    }
}

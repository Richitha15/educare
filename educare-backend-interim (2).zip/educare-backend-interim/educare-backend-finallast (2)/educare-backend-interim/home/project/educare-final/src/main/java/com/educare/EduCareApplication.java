package com.educare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduCareApplication {
    public static void main(String[] args) {
        SpringApplication.run(EduCareApplication.class, args);
    }
}

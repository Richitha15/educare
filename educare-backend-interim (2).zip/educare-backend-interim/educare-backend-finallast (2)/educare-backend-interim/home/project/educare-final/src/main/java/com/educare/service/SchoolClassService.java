package com.educare.service;

import com.educare.dto.request.SchoolClassRequest;
import com.educare.dto.response.SchoolClassResponse;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.SchoolClass;
import com.educare.repository.SchoolClassRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SchoolClassService {

    private final SchoolClassRepository classRepository;

    public List<SchoolClassResponse> getAllClasses() {
        return classRepository.findAll().stream().map(SchoolClassResponse::from).toList();
    }

    public SchoolClassResponse getClassById(Long id) {
        return SchoolClassResponse.from(findById(id));
    }

    public SchoolClassResponse createClass(SchoolClassRequest request) {
        SchoolClass sc = SchoolClass.builder()
            .name(request.getName())
            .gradeLevel(request.getGradeLevel())
            .scheduleJson(request.getScheduleJson())
            .capacity(request.getCapacity() != null ? request.getCapacity() : 30)
            .build();
        return SchoolClassResponse.from(classRepository.save(sc));
    }

    public SchoolClassResponse updateClass(Long id, SchoolClassRequest request) {
        SchoolClass sc = findById(id);
        if (request.getName() != null) sc.setName(request.getName());
        if (request.getGradeLevel() != null) sc.setGradeLevel(request.getGradeLevel());
        if (request.getScheduleJson() != null) sc.setScheduleJson(request.getScheduleJson());
        if (request.getCapacity() != null) sc.setCapacity(request.getCapacity());
        return SchoolClassResponse.from(classRepository.save(sc));
    }

    public void deleteClass(Long id) {
        SchoolClass sc = findById(id);
        sc.setStatus(SchoolClass.ClassStatus.ARCHIVED);
        classRepository.save(sc);
    }

    public SchoolClass findById(Long id) {
        return classRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Class", id));
    }
}

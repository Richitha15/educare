package com.educare.service;

import com.educare.dto.request.MessageRequest;
import com.educare.dto.response.MessageResponse;
import com.educare.exception.BadRequestException;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Message;
import com.educare.model.Student;
import com.educare.model.User;
import com.educare.repository.MessageRepository;
import com.educare.repository.StudentRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class MessageService {

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final EmailService emailService;

    // ============================================
    // Get inbox for current user
    // ============================================
    public List<MessageResponse> getInbox(Long userId) {
        return messageRepository.findAllMessagesForUser(userId)
            .stream().map(MessageResponse::from).toList();
    }

    // ============================================
    // Teacher sends message to parent about a student
    // This sends IN-APP message AND email to parent
    // ============================================
    public MessageResponse sendTeacherMessageToParent(MessageRequest request, User teacherUser) {
        // Validate sender is a TEACHER
        if (teacherUser.getRole() != User.Role.TEACHER) {
            throw new BadRequestException("Only teachers can send messages to parents");
        }

        // Get the parent (recipient)
        User parentUser = userRepository.findById(request.getToUserId())
            .orElseThrow(() -> new ResourceNotFoundException("User", request.getToUserId()));

        // Validate recipient is a PARENT
        if (parentUser.getRole() != User.Role.PARENT) {
            throw new BadRequestException("Teacher messages can only be sent to parents");
        }

        // Get student if provided
        Student student = null;
        if (request.getStudentId() != null) {
            student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student", request.getStudentId()));
        }

        // Save in-app message
        Message message = Message.builder()
            .fromUser(teacherUser)
            .toUser(parentUser)
            .subject(request.getSubject())
            .content(request.getContent())
            .student(student)
            .sentViaEmail(request.isSendEmail())
            .messageType(request.isSendEmail() ? Message.MessageType.BOTH : Message.MessageType.IN_APP)
            .status(Message.MessageStatus.SENT)
            .build();

        MessageResponse response = MessageResponse.from(messageRepository.save(message));

        // Send email to parent if requested
        if (request.isSendEmail()) {
            String parentName = parentUser.getName();
            String teacherName = teacherUser.getName();
            String studentName = student != null ? student.getName() : "your child";
            String subject = request.getSubject() != null ? request.getSubject() : "Message from Teacher";

            emailService.sendTeacherMessageToParent(
                parentUser.getEmail(),
                parentName,
                teacherName,
                studentName,
                subject,
                request.getContent()
            );

            // Also try parent's registered email from student record
            if (student != null && student.getParentEmail() != null
                    && !student.getParentEmail().equals(parentUser.getEmail())) {
                emailService.sendTeacherMessageToParent(
                    student.getParentEmail(),
                    parentName,
                    teacherName,
                    studentName,
                    subject,
                    request.getContent()
                );
            }

            log.info("Teacher {} sent email message to parent {} about student {}",
                teacherUser.getUserId(), parentUser.getUserId(),
                student != null ? student.getStudentId() : "N/A");
        }

        return response;
    }

    // ============================================
    // Mark message as read
    // ============================================
    public MessageResponse markAsRead(Long id) {
        Message message = messageRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Message", id));
        message.setStatus(Message.MessageStatus.READ);
        return MessageResponse.from(messageRepository.save(message));
    }

    public void deleteMessage(Long id) {
        Message message = messageRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Message", id));
        message.setStatus(Message.MessageStatus.DELETED);
        messageRepository.save(message);
    }
}

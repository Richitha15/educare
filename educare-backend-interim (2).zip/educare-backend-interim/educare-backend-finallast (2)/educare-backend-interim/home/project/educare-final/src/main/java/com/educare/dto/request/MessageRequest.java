package com.educare.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MessageRequest {

    @NotNull(message = "Recipient user ID is required")
    private Long toUserId;

    // Subject of the message
    private String subject;

    @NotBlank(message = "Content is required")
    private String content;

    // Student ID - which student this message is about
    private Long studentId;

    // Whether to also send this as an email (teacher to parent)
    private boolean sendEmail = false;
}

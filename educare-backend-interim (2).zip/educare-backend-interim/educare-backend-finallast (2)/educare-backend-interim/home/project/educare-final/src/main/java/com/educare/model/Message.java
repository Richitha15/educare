package com.educare.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "messages")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "message_id")
    private Long messageId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "from_user_id")
    private User fromUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "to_user_id")
    private User toUser;

    // Subject for email messages
    @Column(name = "subject", length = 255)
    private String subject;

    // Student reference - teacher messages about which student
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id")
    private Student student;

    @CreationTimestamp
    @Column(name = "sent_at", updatable = false)
    private LocalDateTime sentAt;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    // Whether this message was also sent via email
    @Column(name = "sent_via_email")
    @Builder.Default
    private Boolean sentViaEmail = false;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private MessageStatus status = MessageStatus.SENT;

    // Type: IN_APP or EMAIL
    @Enumerated(EnumType.STRING)
    @Column(name = "message_type")
    @Builder.Default
    private MessageType messageType = MessageType.IN_APP;

    public enum MessageStatus {
        SENT, READ, DELETED
    }

    public enum MessageType {
        IN_APP, EMAIL, BOTH
    }
}

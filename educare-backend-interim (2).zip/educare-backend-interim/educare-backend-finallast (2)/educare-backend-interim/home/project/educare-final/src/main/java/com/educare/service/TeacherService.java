package com.educare.service;

import com.educare.dto.request.TeacherAssignmentRequest;
import com.educare.dto.request.TeacherRequest;
import com.educare.dto.response.TeacherAssignmentResponse;
import com.educare.dto.response.TeacherResponse;
import com.educare.exception.BadRequestException;
import com.educare.exception.ResourceNotFoundException;
import com.educare.model.Teacher;
import com.educare.model.TeacherAssignment;
import com.educare.model.User;
import com.educare.repository.TeacherAssignmentRepository;
import com.educare.repository.TeacherRepository;
import com.educare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TeacherService {

    private final TeacherRepository teacherRepository;
    private final TeacherAssignmentRepository assignmentRepository;
    private final SchoolClassService classService;
    private final UserRepository userRepository;

    public List<TeacherResponse> getAllTeachers() {
        return teacherRepository.findAll().stream().map(TeacherResponse::from).toList();
    }

    public TeacherResponse getTeacherById(Long id) {
        return TeacherResponse.from(findById(id));
    }

    public TeacherResponse createTeacher(TeacherRequest request) {
        Teacher.TeacherBuilder builder = Teacher.builder()
            .name(request.getName())
            .department(request.getDepartment())
            .contactInfo(request.getContactInfo())
            .email(request.getEmail());

        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
            builder.user(user);
        }

        return TeacherResponse.from(teacherRepository.save(builder.build()));
    }

    public TeacherResponse updateTeacher(Long id, TeacherRequest request) {
        Teacher teacher = findById(id);
        if (request.getName() != null) teacher.setName(request.getName());
        if (request.getDepartment() != null) teacher.setDepartment(request.getDepartment());
        if (request.getContactInfo() != null) teacher.setContactInfo(request.getContactInfo());
        if (request.getEmail() != null) teacher.setEmail(request.getEmail());

        if (request.getUserId() != null) {
            User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", request.getUserId()));
            teacher.setUser(user);
        }

        return TeacherResponse.from(teacherRepository.save(teacher));
    }

    public TeacherAssignmentResponse assignTeacherToClass(
            TeacherAssignmentRequest request, Long assignedByUserId) {
        boolean exists = assignmentRepository
            .existsByTeacherTeacherIdAndSchoolClassClassIdAndStatus(
                request.getTeacherId(), request.getClassId(), TeacherAssignment.AssignStatus.ACTIVE);
        if (exists) throw new BadRequestException("Teacher is already assigned to this class");

        User assignedBy = userRepository.findById(assignedByUserId)
            .orElseThrow(() -> new ResourceNotFoundException("User", assignedByUserId));

        TeacherAssignment assignment = TeacherAssignment.builder()
            .teacher(findById(request.getTeacherId()))
            .schoolClass(classService.findById(request.getClassId()))
            .assignedBy(assignedBy)
            .build();
        return TeacherAssignmentResponse.from(assignmentRepository.save(assignment));
    }

    public List<TeacherAssignmentResponse> getAssignmentsByClass(Long classId) {
        return assignmentRepository.findBySchoolClassClassId(classId)
            .stream().map(TeacherAssignmentResponse::from).toList();
    }

    public List<TeacherAssignmentResponse> getAssignmentsByTeacher(Long teacherId) {
        return assignmentRepository.findByTeacherTeacherId(teacherId)
            .stream().map(TeacherAssignmentResponse::from).toList();
    }

    public Teacher findById(Long id) {
        return teacherRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Teacher", id));
    }
}

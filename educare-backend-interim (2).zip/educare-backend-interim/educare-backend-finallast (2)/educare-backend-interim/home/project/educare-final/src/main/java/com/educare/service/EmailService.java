package com.educare.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${app.mail.from}")
    private String fromEmail;

    @Value("${app.school.name}")
    private String schoolName;

    // ============================================
    // Send user credentials email (Admin use only)
    // ============================================
    public void sendUserCredentials(String toEmail, String userName, String password, String role) {
        String subject = schoolName + " - Your Account Credentials";
        String body = buildCredentialsEmail(userName, toEmail, password, role);
        sendHtmlEmail(toEmail, subject, body);
    }

    // ============================================
    // Send teacher message to parent via email
    // ============================================
    public void sendTeacherMessageToParent(String parentEmail, String parentName,
                                            String teacherName, String studentName,
                                            String subject, String messageContent) {
        String emailSubject = schoolName + " - Message from Teacher: " + subject;
        String body = buildTeacherToParentEmail(parentName, teacherName, studentName, messageContent);
        sendHtmlEmail(parentEmail, emailSubject, body);
    }

    // ============================================
    // Send admin notification email to a user
    // ============================================
    public void sendNotificationEmail(String toEmail, String userName,
                                       String title, String message) {
        String subject = schoolName + " - Notification: " + title;
        String body = buildNotificationEmail(userName, title, message);
        sendHtmlEmail(toEmail, subject, body);
    }

    // ============================================
    // Send broadcast notification email to multiple users
    // ============================================
    public void sendBroadcastEmail(String toEmail, String userName,
                                    String title, String message) {
        sendNotificationEmail(toEmail, userName, title, message);
    }

    // ============================================
    // Core HTML email sender
    // ============================================
    public void sendHtmlEmail(String to, String subject, String htmlContent) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(fromEmail, schoolName);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);
            mailSender.send(mimeMessage);
            log.info("Email sent successfully to: {}", to);
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage());
            // We log but don't throw - email failure should not break the main flow
        }
    }

    // ============================================
    // Simple text email sender
    // ============================================
    public void sendSimpleEmail(String to, String subject, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            mailSender.send(message);
            log.info("Simple email sent to: {}", to);
        } catch (Exception e) {
            log.error("Failed to send simple email to {}: {}", to, e.getMessage());
        }
    }

    // ============================================
    // Email Templates
    // ============================================
    private String buildCredentialsEmail(String name, String email, String password, String role) {
        return """
                <html>
                <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background-color: #2c3e50; padding: 20px; text-align: center;">
                        <h1 style="color: white; margin: 0;">%s</h1>
                        <p style="color: #bdc3c7; margin: 5px 0;">School Management System</p>
                    </div>
                    <div style="padding: 30px; background-color: #f9f9f9;">
                        <h2 style="color: #2c3e50;">Welcome, %s!</h2>
                        <p>Your account has been created. Here are your login credentials:</p>
                        <div style="background-color: #ffffff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin: 20px 0;">
                            <p><strong>Portal:</strong> <a href="http://localhost:3000">EduCare Portal</a></p>
                            <p><strong>Email:</strong> %s</p>
                            <p><strong>Password:</strong> <code style="background:#eee; padding:3px 8px; border-radius:4px;">%s</code></p>
                            <p><strong>Role:</strong> %s</p>
                        </div>
                        <p style="color: #e74c3c;"><strong>Important:</strong> Please change your password after first login.</p>
                        <p>If you have any issues, contact your school administrator.</p>
                    </div>
                    <div style="background-color: #2c3e50; padding: 15px; text-align: center;">
                        <p style="color: #bdc3c7; margin: 0; font-size: 12px;">© %s. All rights reserved.</p>
                    </div>
                </body>
                </html>
                """.formatted(schoolName, name, email, password, role, schoolName);
    }

    private String buildTeacherToParentEmail(String parentName, String teacherName,
                                              String studentName, String messageContent) {
        return """
                <html>
                <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background-color: #2c3e50; padding: 20px; text-align: center;">
                        <h1 style="color: white; margin: 0;">%s</h1>
                    </div>
                    <div style="padding: 30px; background-color: #f9f9f9;">
                        <h2 style="color: #2c3e50;">Dear %s,</h2>
                        <p>You have received a message from <strong>%s</strong> regarding your child <strong>%s</strong>:</p>
                        <div style="background-color: #ffffff; border-left: 4px solid #3498db; padding: 15px 20px; margin: 20px 0; border-radius: 4px;">
                            <p style="margin: 0; color: #333;">%s</p>
                        </div>
                        <p>Please login to the parent portal to reply or view more details.</p>
                        <a href="http://localhost:3000" style="background-color: #3498db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                            View in Portal
                        </a>
                    </div>
                    <div style="background-color: #2c3e50; padding: 15px; text-align: center;">
                        <p style="color: #bdc3c7; margin: 0; font-size: 12px;">© %s. All rights reserved.</p>
                    </div>
                </body>
                </html>
                """.formatted(schoolName, parentName, teacherName, studentName, messageContent, schoolName);
    }

    private String buildNotificationEmail(String userName, String title, String message) {
        return """
                <html>
                <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background-color: #2c3e50; padding: 20px; text-align: center;">
                        <h1 style="color: white; margin: 0;">%s</h1>
                    </div>
                    <div style="padding: 30px; background-color: #f9f9f9;">
                        <h2 style="color: #2c3e50;">Dear %s,</h2>
                        <h3 style="color: #e67e22;">%s</h3>
                        <div style="background-color: #ffffff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin: 20px 0;">
                            <p style="margin: 0; color: #333; line-height: 1.6;">%s</p>
                        </div>
                        <a href="http://localhost:3000" style="background-color: #2c3e50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                            View in Portal
                        </a>
                    </div>
                    <div style="background-color: #2c3e50; padding: 15px; text-align: center;">
                        <p style="color: #bdc3c7; margin: 0; font-size: 12px;">© %s. All rights reserved.</p>
                    </div>
                </body>
                </html>
                """.formatted(schoolName, userName, title, message, schoolName);
    }
}

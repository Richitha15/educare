package com.educare.dto.response;

import com.educare.model.Notification;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class NotificationResponse {

    private Long id;
    private String title;
    private String message;
    private String userName;
    private String userEmail;
    private String role;
    private boolean emailSent;
    private LocalDateTime createdAt;

    // ===============================
    // CONVERT ENTITY TO RESPONSE
    // ===============================
    public static NotificationResponse from(Notification notification) {
        if (notification == null) return null;

        return NotificationResponse.builder()
                .id(notification.getId())
                .title(notification.getTitle())
                .message(notification.getMessage())
                .userName(notification.getUserName())
                .userEmail(notification.getUserEmail())
                .role(notification.getRole())
                .emailSent(notification.isEmailSent())
                .createdAt(notification.getCreatedAt())
                .build();
    }
}